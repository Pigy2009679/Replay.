package com.replay.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import androidx.activity.result.contract.ActivityResultContracts
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "com.replay.app/screen_capture"
    private var pendingResult: MethodChannel.Result? = null

    private val capturePermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val callback = pendingResult
        pendingResult = null
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, ReplayCaptureService::class.java).apply {
                action = ReplayCaptureService.ACTION_START
                putExtra(ReplayCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ReplayCaptureService.EXTRA_DATA, result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            callback?.success(true)
        } else {
            callback?.success(false)
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "startRecording" -> {
                        if (pendingResult != null) {
                            result.error("BUSY", "A permission request is already open.", null)
                            return@setMethodCallHandler
                        }
                        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        pendingResult = result
                        capturePermission.launch(manager.createScreenCaptureIntent())
                    }
                    "pauseRecording" -> sendServiceAction(ReplayCaptureService.ACTION_PAUSE, result)
                    "resumeRecording" -> sendServiceAction(ReplayCaptureService.ACTION_RESUME, result)
                    "stopRecording" -> sendServiceAction(ReplayCaptureService.ACTION_STOP, result)
                    "listRecordings" -> result.success(ReplayCaptureService.listRecordings(this))
                    else -> result.notImplemented()
                }
            }
    }

    private fun sendServiceAction(action: String, result: MethodChannel.Result) {
        try {
            startService(Intent(this, ReplayCaptureService::class.java).setAction(action))
            result.success(null)
        } catch (e: Exception) {
            result.error("SERVICE_ERROR", e.message, null)
        }
    }
}
